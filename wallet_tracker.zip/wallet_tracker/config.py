class Config:
    def __init__(self):
        self.wallet_address = "Eu4oNtQvULhopqAZU7oWzKyorszfrJbqMjQHCL5KtwRV"
        self.helius_api_key = "fbb3c557-e6eb-4eea-9c97-c918478ae72f"
        self.telegram_bot_token = "botTOKEN_GANTI"
        self.telegram_chat_id = "5423274789"
        self.polling_interval = 15  # seconds
        self.last_signature_file = "last_signature.txt"

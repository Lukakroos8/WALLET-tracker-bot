import logging
import json
import os
from typing import List, Dict, Set, Optional, Any
from datetime import datetime
import requests

class TransactionProcessor:
    """Process and filter transactions to avoid duplicates."""

    def __init__(self, config):
        """Initialize the transaction processor."""
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.processed_signatures: Set[str] = set()
        self.last_signature_file = config.last_signature_file
        self.last_processed_signature = None
        self.load_last_signature()

    def load_last_signature(self):
        if os.path.exists(self.last_signature_file):
            with open(self.last_signature_file, "r") as f:
                self.last_processed_signature = f.read().strip()

    def save_last_signature(self):
        if self.last_processed_signature:
            with open(self.last_signature_file, "w") as f:
                f.write(self.last_processed_signature)

    def filter_new_transactions(self, transactions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        new_transactions = []
        for txn in transactions:
            sig = txn.get("signature")
            if not sig:
                continue
            if sig == self.last_processed_signature:
                break
            if sig not in self.processed_signatures:
                new_transactions.append(txn)
                self.processed_signatures.add(sig)
        if new_transactions:
            self.last_processed_signature = new_transactions[0]["signature"]
        return list(reversed(new_transactions))

    def send_telegram_alert(self, txn: Dict[str, Any]):
        msg = f"🔔 New Transaction:
Hash: {txn['signature']}\nType: {txn.get('type', 'N/A')}\nSlot: {txn.get('slot')}\nTimestamp: {txn.get('timestamp')}"
        url = f"https://api.telegram.org/bot{self.config.telegram_bot_token}/sendMessage"
        payload = {"chat_id": self.config.telegram_chat_id, "text": msg}
        try:
            requests.post(url, json=payload)
        except Exception as e:
            self.logger.error(f"Failed to send Telegram alert: {e}")

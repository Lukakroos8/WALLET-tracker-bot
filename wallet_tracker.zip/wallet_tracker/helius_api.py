import requests
import logging

class HeliusAPI:
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)

    def get_transactions(self):
        url = f"https://api.helius.xyz/v0/addresses/{self.config.wallet_address}/transactions?api-key={self.config.helius_api_key}&limit=10"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
        else:
            self.logger.error(f"Helius API error: {response.status_code}, {response.text}")
            return []

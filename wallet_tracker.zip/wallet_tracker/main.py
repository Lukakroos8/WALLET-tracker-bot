import time
import logging
from config import Config
from helius_api import HeliusAPI
from transaction_processor import TransactionProcessor

def main():
    config = Config()
    helius_api = HeliusAPI(config)
    processor = TransactionProcessor(config)

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

    while True:
        try:
            transactions = helius_api.get_transactions()
            new_transactions = processor.filter_new_transactions(transactions)
            for txn in new_transactions:
                processor.send_telegram_alert(txn)
            processor.save_last_signature()
        except Exception as e:
            logger.error(f"Error in main loop: {e}")
        time.sleep(config.polling_interval)

if __name__ == "__main__":
    main()
